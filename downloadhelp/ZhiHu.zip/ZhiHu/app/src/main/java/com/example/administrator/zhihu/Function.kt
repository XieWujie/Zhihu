package com.example.administrator.zhihu

import android.widget.ImageView
import androidx.databinding.BindingAdapter
import com.bumptech.glide.Glide

class Function{
    companion object {

        @JvmStatic
        @BindingAdapter("imageSrc")
        fun setImage(view: ImageView, src:String?){
            Glide.with(view)
                .load(src)
                .placeholder(R.drawable.ic_launcher_background)
                .into(view)
        }
    }
}