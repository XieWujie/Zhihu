package com.example.downloadhelp;

public interface Obtain<T extends Obtain> {

    T obtain();
}
